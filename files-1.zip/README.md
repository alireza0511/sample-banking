# Accessibility Service

Centralized detection and logging of user accessibility features for a Flutter app.

Today it runs pure Flutter — no native code, no plugins. The architecture is built around a small **data-source abstraction** so you can later plug in native iOS / native Android / third-party sources without touching the service, the state, or any feature code.

## File layout

```
lib/core/accessibility/
├── accessibility_state.dart            # plain immutable model (all platforms)
├── accessibility_flag_keys.dart        # shared key constants
├── accessibility_service.dart          # abstract interface
├── accessibility_service_impl.dart     # orchestrates N data sources
├── accessibility_logger.dart           # analytics abstraction
├── accessibility_data_source.dart      # the extension point
└── data_sources/
    └── flutter_accessibility_data_source.dart
```

## What's covered today (Flutter-only)

From `PlatformDispatcher.accessibilityFeatures` + `textScaleFactor`:

| Flag | iOS | Android |
|---|---|---|
| `screenReaderEnabled` | VoiceOver | TalkBack |
| `boldTextEnabled` | ✓ | ✓ |
| `reduceMotionEnabled` | ✓ | ✓ |
| `disableAnimations` | ✓ | ✓ (via Flutter) |
| `highContrastEnabled` | ✓ | ✓ |
| `invertColorsEnabled` | ✓ | ✓ |
| `onOffSwitchLabelsEnabled` | ✓ | n/a |
| `textScaleFactor` | ✓ | ✓ |

For analytics and behavioral branching, these answer the dominant questions: *does this user rely on a screen reader?*, *are they using large text?*, *should we skip animations?*.

## Setup

No codegen, no extra dependencies. Just drop the files in and wire it up.

### 1. Wire up at startup

```dart
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final accessibility = AccessibilityServiceImpl(
    sources: [
      FlutterAccessibilityDataSource(),
      // Add native or third-party sources here later. No other code changes.
    ],
    logger: AccessibilityLoggerImpl(
      eventSink: (name, params) => analytics.logEvent(
        name: name,
        parameters: params,
      ),
    ),
  );
  await accessibility.initialize();

  runApp(
    Provider<AccessibilityService>.value(
      value: accessibility,
      child: const MyApp(),
    ),
  );
}
```

### 2. Branch on accessibility in the UI

```dart
StreamBuilder<AccessibilityState>(
  stream: context.read<AccessibilityService>().stateStream,
  initialData: context.read<AccessibilityService>().currentState,
  builder: (context, snapshot) {
    final a11y = snapshot.data!;
    if (a11y.shouldUseSimplifiedUi) return const SimplifiedTransferFlow();
    if (a11y.shouldDisableAnimations) return const StaticTransferFlow();
    return const RegularTransferFlow();
  },
);
```

Prefer the semantic getters (`shouldUseSimplifiedUi`, `shouldDisableAnimations`, `shouldIncreaseContrast`, `shouldUseLargerTapTargets`) over raw flags — they OR across Flutter and future native sources, so feature code doesn't care which source detected the condition.

## Adding more sources later

The service is source-agnostic. To add coverage:

### Option A — Native iOS/Android (for Switch Control, Guided Access, color correction, enabled service list, etc.)

1. Add a `MethodChannel`-backed class in `ios/` (Swift) and `android/` (Kotlin) that exposes the desired `UIAccessibility` / `AccessibilityManager` flags.
2. Implement `AccessibilityDataSource` in Dart (e.g. `IosNativeAccessibilityDataSource`, `AndroidNativeAccessibilityDataSource`) that talks to the channel and returns a contribution using `AccessibilityFlagKeys`.
3. Append it to the `sources:` list in `main.dart`.

The state model already has the fields — they simply stay `false` until a source populates them.

### Option B — Third-party SDK (vendor accessibility analytics, for example)

1. Implement `AccessibilityDataSource` that wraps the vendor SDK.
2. Map vendor signals onto existing `AccessibilityFlagKeys` where they overlap, or introduce new keys and corresponding fields in `AccessibilityState`.
3. Append to the `sources:` list. Place it *after* sources it should be allowed to override.

### Precedence

Within `refresh()`, sources are read in registration order and later contributions overwrite earlier ones. Put the most authoritative source last. Typical order:

```
[
  FlutterAccessibilityDataSource(),       // baseline, always first
  IosNativeAccessibilityDataSource(),     // iOS-specific detail
  AndroidNativeAccessibilityDataSource(), // Android-specific detail
  VendorXAccessibilityDataSource(),       // final enrichment / correction
]
```

## Notes

- **Live updates** — `FlutterAccessibilityDataSource` uses `WidgetsBindingObserver` hooks (`didChangeAccessibilityFeatures`, `didChangeTextScaleFactor`) and the service also refreshes on `AppLifecycleState.resumed`, so settings changed while in background are picked up immediately on return.
- **Debounce** — the service debounces refresh requests (50 ms default) so bursts of change events from multiple sources cause a single re-read.
- **Source failure isolation** — if one source throws during `initialize`, `read`, or `dispose`, the service logs and continues with the rest. The app never fails to start because of an accessibility read.
- **Privacy** — only feature flags and aggregate counts are logged. No PII. The `enabledAccessibilityServices` list (once a native Android source is added) is retained in state for behavioral decisions; only its length is sent to analytics.
