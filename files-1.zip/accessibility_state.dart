import 'package:flutter/foundation.dart' show listEquals;

/// Immutable snapshot of the user's accessibility configuration.
///
/// Fields fall into three categories:
///  1. **Cross-platform** — populated by `FlutterAccessibilityDataSource`
///     via `PlatformDispatcher.accessibilityFeatures`. Work on both iOS
///     and Android today with zero native code.
///  2. **iOS-only** — default to `false` until an iOS native data source
///     is registered. Safe to read on Android (always `false`).
///  3. **Android-only** — default to `false` until an Android native
///     data source is registered. Safe to read on iOS (always `false`).
///
/// The [hasAnyAccessibilityFeatureEnabled] and `should*` getters are
/// OR-composed across all fields, so they give the right answer
/// regardless of which sources are currently active.
final class AccessibilityState {
  const AccessibilityState({
    // Cross-platform
    this.screenReaderEnabled = false,
    this.boldTextEnabled = false,
    this.reduceMotionEnabled = false,
    this.disableAnimations = false,
    this.highContrastEnabled = false,
    this.invertColorsEnabled = false,
    this.onOffSwitchLabelsEnabled = false,
    this.textScaleFactor = 1.0,
    // iOS
    this.switchControlEnabled = false,
    this.assistiveTouchEnabled = false,
    this.speakScreenEnabled = false,
    this.speakSelectionEnabled = false,
    this.grayscaleEnabled = false,
    this.reduceTransparencyEnabled = false,
    this.darkerSystemColorsEnabled = false,
    this.buttonShapesEnabled = false,
    this.guidedAccessEnabled = false,
    // Android
    this.talkBackEnabled = false,
    this.switchAccessEnabled = false,
    this.selectToSpeakEnabled = false,
    this.highTextContrastEnabled = false,
    this.colorInversionEnabled = false,
    this.colorCorrectionEnabled = false,
    this.magnificationEnabled = false,
    this.removeAnimationsEnabled = false,
    this.touchExplorationEnabled = false,
    this.enabledAccessibilityServices = const <String>[],
    this.fontScale = 1.0,
  });

  // ---- Cross-platform (Flutter) ----
  final bool screenReaderEnabled; // VoiceOver / TalkBack
  final bool boldTextEnabled;
  final bool reduceMotionEnabled;
  final bool disableAnimations;
  final bool highContrastEnabled;
  final bool invertColorsEnabled;
  final bool onOffSwitchLabelsEnabled;
  final double textScaleFactor;

  // ---- iOS-only (requires a native source) ----
  final bool switchControlEnabled;
  final bool assistiveTouchEnabled;
  final bool speakScreenEnabled;
  final bool speakSelectionEnabled;
  final bool grayscaleEnabled;
  final bool reduceTransparencyEnabled;
  final bool darkerSystemColorsEnabled;
  final bool buttonShapesEnabled;
  final bool guidedAccessEnabled;

  // ---- Android-only (requires a native source) ----
  final bool talkBackEnabled;
  final bool switchAccessEnabled;
  final bool selectToSpeakEnabled;
  final bool highTextContrastEnabled;
  final bool colorInversionEnabled;
  final bool colorCorrectionEnabled;
  final bool magnificationEnabled;
  final bool removeAnimationsEnabled;
  final bool touchExplorationEnabled;
  final List<String> enabledAccessibilityServices;
  final double fontScale;

  /// Coarse-grained signal: is *any* accessibility feature active.
  /// Useful as a single analytics dimension.
  bool get hasAnyAccessibilityFeatureEnabled =>
      screenReaderEnabled ||
      boldTextEnabled ||
      reduceMotionEnabled ||
      disableAnimations ||
      highContrastEnabled ||
      invertColorsEnabled ||
      onOffSwitchLabelsEnabled ||
      switchControlEnabled ||
      assistiveTouchEnabled ||
      speakScreenEnabled ||
      speakSelectionEnabled ||
      grayscaleEnabled ||
      reduceTransparencyEnabled ||
      darkerSystemColorsEnabled ||
      buttonShapesEnabled ||
      guidedAccessEnabled ||
      talkBackEnabled ||
      switchAccessEnabled ||
      selectToSpeakEnabled ||
      highTextContrastEnabled ||
      colorInversionEnabled ||
      colorCorrectionEnabled ||
      magnificationEnabled ||
      removeAnimationsEnabled ||
      touchExplorationEnabled ||
      enabledAccessibilityServices.isNotEmpty ||
      textScaleFactor > 1.0 ||
      fontScale > 1.0;

  /// Semantic getters — prefer these in feature code so UI logic is
  /// independent of which source populated the underlying flag.

  bool get shouldUseSimplifiedUi =>
      screenReaderEnabled ||
      talkBackEnabled ||
      switchControlEnabled ||
      switchAccessEnabled ||
      touchExplorationEnabled;

  bool get shouldDisableAnimations =>
      reduceMotionEnabled || disableAnimations || removeAnimationsEnabled;

  bool get shouldIncreaseContrast =>
      highContrastEnabled ||
      highTextContrastEnabled ||
      darkerSystemColorsEnabled;

  bool get shouldUseLargerTapTargets =>
      shouldUseSimplifiedUi || magnificationEnabled || fontScale >= 1.3;

  /// Returns a new state with the given fields replaced. Pass `null` to
  /// keep the existing value.
  AccessibilityState copyWith({
    bool? screenReaderEnabled,
    bool? boldTextEnabled,
    bool? reduceMotionEnabled,
    bool? disableAnimations,
    bool? highContrastEnabled,
    bool? invertColorsEnabled,
    bool? onOffSwitchLabelsEnabled,
    double? textScaleFactor,
    bool? switchControlEnabled,
    bool? assistiveTouchEnabled,
    bool? speakScreenEnabled,
    bool? speakSelectionEnabled,
    bool? grayscaleEnabled,
    bool? reduceTransparencyEnabled,
    bool? darkerSystemColorsEnabled,
    bool? buttonShapesEnabled,
    bool? guidedAccessEnabled,
    bool? talkBackEnabled,
    bool? switchAccessEnabled,
    bool? selectToSpeakEnabled,
    bool? highTextContrastEnabled,
    bool? colorInversionEnabled,
    bool? colorCorrectionEnabled,
    bool? magnificationEnabled,
    bool? removeAnimationsEnabled,
    bool? touchExplorationEnabled,
    List<String>? enabledAccessibilityServices,
    double? fontScale,
  }) {
    return AccessibilityState(
      screenReaderEnabled: screenReaderEnabled ?? this.screenReaderEnabled,
      boldTextEnabled: boldTextEnabled ?? this.boldTextEnabled,
      reduceMotionEnabled: reduceMotionEnabled ?? this.reduceMotionEnabled,
      disableAnimations: disableAnimations ?? this.disableAnimations,
      highContrastEnabled: highContrastEnabled ?? this.highContrastEnabled,
      invertColorsEnabled: invertColorsEnabled ?? this.invertColorsEnabled,
      onOffSwitchLabelsEnabled:
          onOffSwitchLabelsEnabled ?? this.onOffSwitchLabelsEnabled,
      textScaleFactor: textScaleFactor ?? this.textScaleFactor,
      switchControlEnabled: switchControlEnabled ?? this.switchControlEnabled,
      assistiveTouchEnabled:
          assistiveTouchEnabled ?? this.assistiveTouchEnabled,
      speakScreenEnabled: speakScreenEnabled ?? this.speakScreenEnabled,
      speakSelectionEnabled:
          speakSelectionEnabled ?? this.speakSelectionEnabled,
      grayscaleEnabled: grayscaleEnabled ?? this.grayscaleEnabled,
      reduceTransparencyEnabled:
          reduceTransparencyEnabled ?? this.reduceTransparencyEnabled,
      darkerSystemColorsEnabled:
          darkerSystemColorsEnabled ?? this.darkerSystemColorsEnabled,
      buttonShapesEnabled: buttonShapesEnabled ?? this.buttonShapesEnabled,
      guidedAccessEnabled: guidedAccessEnabled ?? this.guidedAccessEnabled,
      talkBackEnabled: talkBackEnabled ?? this.talkBackEnabled,
      switchAccessEnabled: switchAccessEnabled ?? this.switchAccessEnabled,
      selectToSpeakEnabled: selectToSpeakEnabled ?? this.selectToSpeakEnabled,
      highTextContrastEnabled:
          highTextContrastEnabled ?? this.highTextContrastEnabled,
      colorInversionEnabled:
          colorInversionEnabled ?? this.colorInversionEnabled,
      colorCorrectionEnabled:
          colorCorrectionEnabled ?? this.colorCorrectionEnabled,
      magnificationEnabled: magnificationEnabled ?? this.magnificationEnabled,
      removeAnimationsEnabled:
          removeAnimationsEnabled ?? this.removeAnimationsEnabled,
      touchExplorationEnabled:
          touchExplorationEnabled ?? this.touchExplorationEnabled,
      enabledAccessibilityServices:
          enabledAccessibilityServices ?? this.enabledAccessibilityServices,
      fontScale: fontScale ?? this.fontScale,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! AccessibilityState) return false;
    return screenReaderEnabled == other.screenReaderEnabled &&
        boldTextEnabled == other.boldTextEnabled &&
        reduceMotionEnabled == other.reduceMotionEnabled &&
        disableAnimations == other.disableAnimations &&
        highContrastEnabled == other.highContrastEnabled &&
        invertColorsEnabled == other.invertColorsEnabled &&
        onOffSwitchLabelsEnabled == other.onOffSwitchLabelsEnabled &&
        textScaleFactor == other.textScaleFactor &&
        switchControlEnabled == other.switchControlEnabled &&
        assistiveTouchEnabled == other.assistiveTouchEnabled &&
        speakScreenEnabled == other.speakScreenEnabled &&
        speakSelectionEnabled == other.speakSelectionEnabled &&
        grayscaleEnabled == other.grayscaleEnabled &&
        reduceTransparencyEnabled == other.reduceTransparencyEnabled &&
        darkerSystemColorsEnabled == other.darkerSystemColorsEnabled &&
        buttonShapesEnabled == other.buttonShapesEnabled &&
        guidedAccessEnabled == other.guidedAccessEnabled &&
        talkBackEnabled == other.talkBackEnabled &&
        switchAccessEnabled == other.switchAccessEnabled &&
        selectToSpeakEnabled == other.selectToSpeakEnabled &&
        highTextContrastEnabled == other.highTextContrastEnabled &&
        colorInversionEnabled == other.colorInversionEnabled &&
        colorCorrectionEnabled == other.colorCorrectionEnabled &&
        magnificationEnabled == other.magnificationEnabled &&
        removeAnimationsEnabled == other.removeAnimationsEnabled &&
        touchExplorationEnabled == other.touchExplorationEnabled &&
        fontScale == other.fontScale &&
        listEquals(
          enabledAccessibilityServices,
          other.enabledAccessibilityServices,
        );
  }

  @override
  int get hashCode => Object.hashAll(<Object?>[
        screenReaderEnabled,
        boldTextEnabled,
        reduceMotionEnabled,
        disableAnimations,
        highContrastEnabled,
        invertColorsEnabled,
        onOffSwitchLabelsEnabled,
        textScaleFactor,
        switchControlEnabled,
        assistiveTouchEnabled,
        speakScreenEnabled,
        speakSelectionEnabled,
        grayscaleEnabled,
        reduceTransparencyEnabled,
        darkerSystemColorsEnabled,
        buttonShapesEnabled,
        guidedAccessEnabled,
        talkBackEnabled,
        switchAccessEnabled,
        selectToSpeakEnabled,
        highTextContrastEnabled,
        colorInversionEnabled,
        colorCorrectionEnabled,
        magnificationEnabled,
        removeAnimationsEnabled,
        touchExplorationEnabled,
        fontScale,
        Object.hashAll(enabledAccessibilityServices),
      ]);

  @override
  String toString() => 'AccessibilityState('
      'anyEnabled: $hasAnyAccessibilityFeatureEnabled, '
      'screenReader: $screenReaderEnabled, '
      'boldText: $boldTextEnabled, '
      'reduceMotion: $reduceMotionEnabled, '
      'highContrast: $highContrastEnabled, '
      'invertColors: $invertColorsEnabled, '
      'textScale: $textScaleFactor, '
      'fontScale: $fontScale, '
      'enabledServices: ${enabledAccessibilityServices.length}'
      ')';
}
