import 'dart:async';
import 'dart:ui';

import 'package:flutter/widgets.dart';

import '../accessibility_data_source.dart';
import '../accessibility_flag_keys.dart';

/// Reads accessibility signals that Flutter exposes natively via
/// `PlatformDispatcher.accessibilityFeatures` and
/// `PlatformDispatcher.textScaleFactor`.
///
/// These flags work on both iOS and Android today with zero native
/// code, and cover the dominant signals for accessibility analytics:
/// screen reader, bold text, reduce motion, high contrast, invert
/// colors, and text scale.
///
/// When you later need platform-specific flags (Switch Control, Guided
/// Access, Android magnification, enabled service list, etc.), add an
/// additional [AccessibilityDataSource] alongside this one — no changes
/// required here.
class FlutterAccessibilityDataSource
    with WidgetsBindingObserver
    implements AccessibilityDataSource {
  final StreamController<void> _changes = StreamController<void>.broadcast();
  bool _initialized = false;

  @override
  String get id => 'flutter';

  @override
  Stream<void> get onChanged => _changes.stream;

  @override
  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  Future<AccessibilityContribution> read() async {
    final dispatcher = PlatformDispatcher.instance;
    final features = dispatcher.accessibilityFeatures;

    return <String, Object?>{
      AccessibilityFlagKeys.screenReader: features.accessibleNavigation,
      AccessibilityFlagKeys.boldText: features.boldText,
      AccessibilityFlagKeys.reduceMotion: features.reduceMotion,
      AccessibilityFlagKeys.disableAnimations: features.disableAnimations,
      AccessibilityFlagKeys.highContrast: features.highContrast,
      AccessibilityFlagKeys.invertColors: features.invertColors,
      AccessibilityFlagKeys.onOffSwitchLabels: features.onOffSwitchLabels,
      AccessibilityFlagKeys.textScaleFactor: dispatcher.textScaleFactor,
    };
  }

  @override
  void didChangeAccessibilityFeatures() {
    if (!_changes.isClosed) _changes.add(null);
  }

  @override
  void didChangeTextScaleFactor() {
    if (!_changes.isClosed) _changes.add(null);
  }

  @override
  Future<void> dispose() async {
    if (!_initialized) return;
    WidgetsBinding.instance.removeObserver(this);
    await _changes.close();
    _initialized = false;
  }
}
