import 'package:freezed_annotation/freezed_annotation.dart';

part 'accessibility_state.freezed.dart';
part 'accessibility_state.g.dart';

/// Immutable snapshot of the user's accessibility configuration.
///
/// Fields fall into three categories:
///  1. **Cross-platform** — populated by [FlutterAccessibilityDataSource]
///     via `PlatformDispatcher.accessibilityFeatures`. Work on both iOS
///     and Android today with zero native code.
///  2. **iOS-only** — default to `false` until an iOS native data source
///     is registered. Safe to read on Android (always `false`).
///  3. **Android-only** — default to `false` until an Android native
///     data source is registered. Safe to read on iOS (always `false`).
///
/// The [hasAnyAccessibilityFeatureEnabled] and `should*` getters are
/// OR-composed across all fields, so they give the right answer
/// regardless of which sources are currently active.
@freezed
class AccessibilityState with _$AccessibilityState {
  const factory AccessibilityState({
    // ---- Cross-platform (Flutter) ----
    @Default(false) bool screenReaderEnabled, // VoiceOver / TalkBack
    @Default(false) bool boldTextEnabled,
    @Default(false) bool reduceMotionEnabled,
    @Default(false) bool disableAnimations,
    @Default(false) bool highContrastEnabled,
    @Default(false) bool invertColorsEnabled,
    @Default(false) bool onOffSwitchLabelsEnabled,
    @Default(1.0) double textScaleFactor,

    // ---- iOS-only (requires a native source) ----
    @Default(false) bool switchControlEnabled,
    @Default(false) bool assistiveTouchEnabled,
    @Default(false) bool speakScreenEnabled,
    @Default(false) bool speakSelectionEnabled,
    @Default(false) bool grayscaleEnabled,
    @Default(false) bool reduceTransparencyEnabled,
    @Default(false) bool darkerSystemColorsEnabled,
    @Default(false) bool buttonShapesEnabled,
    @Default(false) bool guidedAccessEnabled,

    // ---- Android-only (requires a native source) ----
    @Default(false) bool talkBackEnabled,
    @Default(false) bool switchAccessEnabled,
    @Default(false) bool selectToSpeakEnabled,
    @Default(false) bool highTextContrastEnabled,
    @Default(false) bool colorInversionEnabled,
    @Default(false) bool colorCorrectionEnabled,
    @Default(false) bool magnificationEnabled,
    @Default(false) bool removeAnimationsEnabled,
    @Default(false) bool touchExplorationEnabled,
    @Default(<String>[]) List<String> enabledAccessibilityServices,
    @Default(1.0) double fontScale,
  }) = _AccessibilityState;

  const AccessibilityState._();

  factory AccessibilityState.fromJson(Map<String, dynamic> json) =>
      _$AccessibilityStateFromJson(json);

  /// Coarse-grained signal: is *any* accessibility feature active.
  /// Useful as a single analytics dimension.
  bool get hasAnyAccessibilityFeatureEnabled =>
      screenReaderEnabled ||
      boldTextEnabled ||
      reduceMotionEnabled ||
      disableAnimations ||
      highContrastEnabled ||
      invertColorsEnabled ||
      onOffSwitchLabelsEnabled ||
      switchControlEnabled ||
      assistiveTouchEnabled ||
      speakScreenEnabled ||
      speakSelectionEnabled ||
      grayscaleEnabled ||
      reduceTransparencyEnabled ||
      darkerSystemColorsEnabled ||
      buttonShapesEnabled ||
      guidedAccessEnabled ||
      talkBackEnabled ||
      switchAccessEnabled ||
      selectToSpeakEnabled ||
      highTextContrastEnabled ||
      colorInversionEnabled ||
      colorCorrectionEnabled ||
      magnificationEnabled ||
      removeAnimationsEnabled ||
      touchExplorationEnabled ||
      enabledAccessibilityServices.isNotEmpty ||
      textScaleFactor > 1.0 ||
      fontScale > 1.0;

  /// Semantic getters — prefer these in feature code so UI logic is
  /// independent of which source populated the underlying flag.

  bool get shouldUseSimplifiedUi =>
      screenReaderEnabled ||
      talkBackEnabled ||
      switchControlEnabled ||
      switchAccessEnabled ||
      touchExplorationEnabled;

  bool get shouldDisableAnimations =>
      reduceMotionEnabled || disableAnimations || removeAnimationsEnabled;

  bool get shouldIncreaseContrast =>
      highContrastEnabled ||
      highTextContrastEnabled ||
      darkerSystemColorsEnabled;

  bool get shouldUseLargerTapTargets =>
      shouldUseSimplifiedUi || magnificationEnabled || fontScale >= 1.3;
}
