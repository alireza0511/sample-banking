/// Stable string keys used by [AccessibilityDataSource]s to contribute
/// values to the merged accessibility state.
///
/// Using constants rather than magic strings keeps sources and the state
/// builder in lockstep. When a new source is added (native iOS, native
/// Android, a third-party SDK), declare its keys here so every layer
/// agrees on the vocabulary.
abstract final class AccessibilityFlagKeys {
  // ---- Cross-platform (populated by FlutterAccessibilityDataSource) ----
  static const String screenReader = 'screenReader';
  static const String boldText = 'boldText';
  static const String reduceMotion = 'reduceMotion';
  static const String disableAnimations = 'disableAnimations';
  static const String highContrast = 'highContrast';
  static const String invertColors = 'invertColors';
  static const String onOffSwitchLabels = 'onOffSwitchLabels';
  static const String textScaleFactor = 'textScaleFactor';

  // ---- iOS (reserved for a future native source) ----
  static const String switchControl = 'switchControl';
  static const String assistiveTouch = 'assistiveTouch';
  static const String speakScreen = 'speakScreen';
  static const String speakSelection = 'speakSelection';
  static const String grayscale = 'grayscale';
  static const String reduceTransparency = 'reduceTransparency';
  static const String darkerSystemColors = 'darkerSystemColors';
  static const String buttonShapes = 'buttonShapes';
  static const String guidedAccess = 'guidedAccess';

  // ---- Android (reserved for a future native source) ----
  static const String talkBack = 'talkBack';
  static const String switchAccess = 'switchAccess';
  static const String selectToSpeak = 'selectToSpeak';
  static const String highTextContrast = 'highTextContrast';
  static const String colorInversion = 'colorInversion';
  static const String colorCorrection = 'colorCorrection';
  static const String magnification = 'magnification';
  static const String removeAnimations = 'removeAnimations';
  static const String touchExploration = 'touchExploration';
  static const String enabledServices = 'enabledServices';
  static const String fontScale = 'fontScale';
}
