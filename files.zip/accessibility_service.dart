import 'accessibility_state.dart';

/// Central API for reading the user's accessibility configuration and
/// observing changes.
///
/// The service is composed of one or more [AccessibilityDataSource]s
/// that supply the underlying signals. Consumers depend only on this
/// interface and on [AccessibilityState], so new sources can be added
/// without touching feature code.
abstract class AccessibilityService {
  /// The current snapshot. Never null; defaults to an all-false state
  /// until [initialize] completes.
  AccessibilityState get currentState;

  /// Broadcast stream of state changes. Emits only when the merged
  /// state actually changes (equality-based dedup).
  Stream<AccessibilityState> get stateStream;

  /// Starts all registered data sources and performs an initial read.
  /// Safe to call more than once; subsequent calls are no-ops.
  Future<void> initialize();

  /// Forces a re-read from every source. Useful from lifecycle hooks
  /// or from debug tooling.
  Future<AccessibilityState> refresh();

  /// Tears down all sources and closes the stream.
  Future<void> dispose();
}
