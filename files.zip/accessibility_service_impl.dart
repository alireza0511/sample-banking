import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import 'accessibility_data_source.dart';
import 'accessibility_flag_keys.dart';
import 'accessibility_logger.dart';
import 'accessibility_service.dart';
import 'accessibility_state.dart';

/// Orchestrates a list of [AccessibilityDataSource]s, merges their
/// contributions, and publishes the merged [AccessibilityState].
///
/// The service itself is unaware of what any particular source does —
/// it only cares about their `read()` output and `onChanged` stream.
/// This is what keeps the design open for future additions (native iOS,
/// native Android, third-party SDKs).
///
/// ```dart
/// final service = AccessibilityServiceImpl(
///   sources: [
///     FlutterAccessibilityDataSource(),
///     // IosNativeAccessibilityDataSource(),      // later
///     // AndroidNativeAccessibilityDataSource(),  // later
///   ],
///   logger: AccessibilityLoggerImpl(eventSink: myAnalytics.logEvent),
/// );
/// await service.initialize();
/// ```
class AccessibilityServiceImpl
    with WidgetsBindingObserver
    implements AccessibilityService {
  AccessibilityServiceImpl({
    required List<AccessibilityDataSource> sources,
    AccessibilityLogger? logger,
    Duration refreshDebounce = const Duration(milliseconds: 50),
  })  : assert(sources.isNotEmpty, 'At least one data source is required'),
        _sources = List.unmodifiable(sources),
        _logger = logger,
        _debounce = refreshDebounce;

  final List<AccessibilityDataSource> _sources;
  final AccessibilityLogger? _logger;
  final Duration _debounce;

  final StreamController<AccessibilityState> _controller =
      StreamController<AccessibilityState>.broadcast();
  final List<StreamSubscription<void>> _subscriptions = [];
  Timer? _debounceTimer;

  AccessibilityState _state = const AccessibilityState();
  bool _initialized = false;
  bool _disposed = false;

  @override
  AccessibilityState get currentState => _state;

  @override
  Stream<AccessibilityState> get stateStream => _controller.stream;

  @override
  Future<void> initialize() async {
    if (_initialized || _disposed) return;
    _initialized = true;

    WidgetsBinding.instance.addObserver(this);

    // Bring every source online and subscribe to its change stream.
    for (final source in _sources) {
      try {
        await source.initialize();
      } catch (e, st) {
        _logSourceFailure(source, 'initialize', e, st);
      }
      _subscriptions.add(
        source.onChanged.listen(
          (_) => _scheduleRefresh(),
          onError: (Object e, StackTrace st) =>
              _logSourceFailure(source, 'onChanged', e, st),
        ),
      );
    }

    await refresh();
    _logger?.logInitialState(_state);
  }

  @override
  Future<AccessibilityState> refresh() async {
    if (_disposed) return _state;

    // Read every source in registration order. Later sources override
    // earlier ones, which is how native/third-party layers can enrich
    // or correct the Flutter baseline.
    final merged = <String, Object?>{};
    for (final source in _sources) {
      try {
        final contribution = await source.read();
        merged.addAll(contribution);
      } catch (e, st) {
        _logSourceFailure(source, 'read', e, st);
      }
    }

    final next = _buildState(merged);
    _emit(next);
    return next;
  }

  @override
  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;

    _debounceTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);

    for (final sub in _subscriptions) {
      await sub.cancel();
    }
    _subscriptions.clear();

    for (final source in _sources) {
      try {
        await source.dispose();
      } catch (e, st) {
        _logSourceFailure(source, 'dispose', e, st);
      }
    }

    await _controller.close();
  }

  // --- Lifecycle hooks ------------------------------------------------

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // User may have toggled a setting while we were backgrounded.
    if (state == AppLifecycleState.resumed) {
      _scheduleRefresh();
    }
  }

  // --- Internals ------------------------------------------------------

  void _scheduleRefresh() {
    if (_disposed) return;
    _debounceTimer?.cancel();
    _debounceTimer = Timer(_debounce, refresh);
  }

  void _emit(AccessibilityState next) {
    if (next == _state) return;
    final previous = _state;
    _state = next;
    if (!_controller.isClosed) _controller.add(next);
    _logger?.logStateChange(previous: previous, current: next);
  }

  AccessibilityState _buildState(Map<String, Object?> m) {
    bool b(String k) => m[k] as bool? ?? false;
    double d(String k, double fallback) =>
        (m[k] as num?)?.toDouble() ?? fallback;
    List<String> s(String k) =>
        (m[k] as List?)?.cast<String>() ?? const <String>[];

    return AccessibilityState(
      // Cross-platform
      screenReaderEnabled: b(AccessibilityFlagKeys.screenReader),
      boldTextEnabled: b(AccessibilityFlagKeys.boldText),
      reduceMotionEnabled: b(AccessibilityFlagKeys.reduceMotion),
      disableAnimations: b(AccessibilityFlagKeys.disableAnimations),
      highContrastEnabled: b(AccessibilityFlagKeys.highContrast),
      invertColorsEnabled: b(AccessibilityFlagKeys.invertColors),
      onOffSwitchLabelsEnabled: b(AccessibilityFlagKeys.onOffSwitchLabels),
      textScaleFactor: d(AccessibilityFlagKeys.textScaleFactor, 1.0),
      // iOS
      switchControlEnabled: b(AccessibilityFlagKeys.switchControl),
      assistiveTouchEnabled: b(AccessibilityFlagKeys.assistiveTouch),
      speakScreenEnabled: b(AccessibilityFlagKeys.speakScreen),
      speakSelectionEnabled: b(AccessibilityFlagKeys.speakSelection),
      grayscaleEnabled: b(AccessibilityFlagKeys.grayscale),
      reduceTransparencyEnabled: b(AccessibilityFlagKeys.reduceTransparency),
      darkerSystemColorsEnabled: b(AccessibilityFlagKeys.darkerSystemColors),
      buttonShapesEnabled: b(AccessibilityFlagKeys.buttonShapes),
      guidedAccessEnabled: b(AccessibilityFlagKeys.guidedAccess),
      // Android
      talkBackEnabled: b(AccessibilityFlagKeys.talkBack),
      switchAccessEnabled: b(AccessibilityFlagKeys.switchAccess),
      selectToSpeakEnabled: b(AccessibilityFlagKeys.selectToSpeak),
      highTextContrastEnabled: b(AccessibilityFlagKeys.highTextContrast),
      colorInversionEnabled: b(AccessibilityFlagKeys.colorInversion),
      colorCorrectionEnabled: b(AccessibilityFlagKeys.colorCorrection),
      magnificationEnabled: b(AccessibilityFlagKeys.magnification),
      removeAnimationsEnabled: b(AccessibilityFlagKeys.removeAnimations),
      touchExplorationEnabled: b(AccessibilityFlagKeys.touchExploration),
      enabledAccessibilityServices: s(AccessibilityFlagKeys.enabledServices),
      fontScale: d(AccessibilityFlagKeys.fontScale, 1.0),
    );
  }

  void _logSourceFailure(
    AccessibilityDataSource source,
    String phase,
    Object error,
    StackTrace stackTrace,
  ) {
    debugPrint(
      '[AccessibilityService] source "${source.id}" failed during $phase: $error',
    );
    debugPrintStack(stackTrace: stackTrace);
  }
}
