import 'dart:async';

/// The payload a data source contributes to the merged accessibility
/// state. Keys should come from [AccessibilityFlagKeys] so sources and
/// the state builder stay in sync.
typedef AccessibilityContribution = Map<String, Object?>;

/// A pluggable source of accessibility signals.
///
/// The [AccessibilityService] composes any number of these: the Flutter
/// source is always present; iOS and Android native sources can be
/// added later by registering additional implementations; a third-party
/// vendor SDK (for example, an accessibility analytics product) can
/// likewise plug in without any change to the service or the state.
///
/// ### Ordering and precedence
///
/// Sources are read in the order they're registered with the service.
/// When multiple sources contribute the same key, later sources override
/// earlier ones. The convention is to put the most authoritative source
/// last:
///
/// ```
/// [
///   FlutterAccessibilityDataSource(),        // baseline
///   IosNativeAccessibilityDataSource(),      // overrides on iOS
///   AndroidNativeAccessibilityDataSource(),  // overrides on Android
///   VendorXDataSource(),                     // final enrichment
/// ]
/// ```
///
/// ### Contract
///
///  - [initialize] is called exactly once by the service.
///  - [read] must be idempotent — the service may call it at any time,
///    including from a resume event.
///  - [onChanged] should emit whenever the source's underlying values
///    change. The service will debounce and re-read.
///  - [dispose] is called exactly once and must release all resources.
abstract class AccessibilityDataSource {
  /// Unique, stable identifier for logging and debugging
  /// (e.g. `'flutter'`, `'ios_native'`, `'vendor_x'`).
  String get id;

  /// Prepare the source (e.g. register platform listeners). Called once
  /// by the service during its own initialization.
  Future<void> initialize();

  /// Read a fresh snapshot of the flags this source owns. Keys not
  /// returned are left at their previous or default value.
  Future<AccessibilityContribution> read();

  /// Emits whenever the underlying values change. The service listens
  /// and triggers a (debounced) re-read.
  Stream<void> get onChanged;

  /// Release any resources held by this source.
  Future<void> dispose();
}
