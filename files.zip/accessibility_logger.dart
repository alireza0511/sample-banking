import 'accessibility_state.dart';

/// Abstraction for reporting accessibility usage to analytics.
///
/// Keep this pluggable so unit tests can assert on events without
/// touching real SDKs, and so swapping Firebase → Amplitude → in-house
/// is a one-line change.
abstract class AccessibilityLogger {
  /// Emitted once right after the service initializes so you can capture
  /// the user's accessibility configuration at session start.
  void logInitialState(AccessibilityState state);

  /// Emitted when the OS reports a change while the app is running.
  /// The payload is a diff (only changed keys) so analytics events
  /// stay small.
  void logStateChange({
    required AccessibilityState previous,
    required AccessibilityState current,
  });
}

/// Default logger that forwards structured events to a caller-provided
/// sink. This keeps the analytics SDK out of this module.
///
/// Example wiring with Firebase Analytics:
/// ```dart
/// AccessibilityLoggerImpl(
///   eventSink: (name, params) => FirebaseAnalytics.instance.logEvent(
///     name: name,
///     parameters: params.map(
///       (k, v) => MapEntry(k, v is bool ? (v ? 1 : 0) : v),
///     ),
///   ),
/// );
/// ```
class AccessibilityLoggerImpl implements AccessibilityLogger {
  AccessibilityLoggerImpl({required this.eventSink});

  final void Function(String name, Map<String, Object?> parameters) eventSink;

  static const String _eventSessionStart = 'accessibility_session_start';
  static const String _eventFeatureChanged = 'accessibility_feature_changed';

  @override
  void logInitialState(AccessibilityState state) {
    eventSink(_eventSessionStart, _toParams(state));
  }

  @override
  void logStateChange({
    required AccessibilityState previous,
    required AccessibilityState current,
  }) {
    final diff = _diff(previous, current);
    if (diff.isEmpty) return;
    eventSink(_eventFeatureChanged, {
      ...diff,
      'any_enabled': current.hasAnyAccessibilityFeatureEnabled,
    });
  }

  Map<String, Object?> _toParams(AccessibilityState s) => <String, Object?>{
        'any_enabled': s.hasAnyAccessibilityFeatureEnabled,
        // Cross-platform
        'screen_reader': s.screenReaderEnabled,
        'bold_text': s.boldTextEnabled,
        'reduce_motion': s.reduceMotionEnabled,
        'disable_animations': s.disableAnimations,
        'high_contrast': s.highContrastEnabled,
        'invert_colors': s.invertColorsEnabled,
        'on_off_labels': s.onOffSwitchLabelsEnabled,
        'text_scale': s.textScaleFactor,
        // iOS (remain false until a native source is added)
        'switch_control': s.switchControlEnabled,
        'assistive_touch': s.assistiveTouchEnabled,
        'speak_screen': s.speakScreenEnabled,
        'speak_selection': s.speakSelectionEnabled,
        'grayscale': s.grayscaleEnabled,
        'reduce_transparency': s.reduceTransparencyEnabled,
        'darker_colors': s.darkerSystemColorsEnabled,
        'button_shapes': s.buttonShapesEnabled,
        'guided_access': s.guidedAccessEnabled,
        // Android (remain false until a native source is added)
        'talkback': s.talkBackEnabled,
        'switch_access': s.switchAccessEnabled,
        'select_to_speak': s.selectToSpeakEnabled,
        'high_text_contrast': s.highTextContrastEnabled,
        'color_inversion': s.colorInversionEnabled,
        'color_correction': s.colorCorrectionEnabled,
        'magnification': s.magnificationEnabled,
        'remove_animations': s.removeAnimationsEnabled,
        'touch_exploration': s.touchExplorationEnabled,
        'font_scale': s.fontScale,
        'enabled_service_count': s.enabledAccessibilityServices.length,
      };

  Map<String, Object?> _diff(AccessibilityState prev, AccessibilityState curr) {
    final a = _toParams(prev);
    final b = _toParams(curr);
    final diff = <String, Object?>{};
    for (final key in b.keys) {
      if (a[key] != b[key]) {
        diff['${key}_from'] = a[key];
        diff['${key}_to'] = b[key];
      }
    }
    return diff;
  }
}
